<div class="col-sm-12">

    <div class="row justify-content-between">
        <div class="col-md-5 col-lg-4">
            <div class="property-price d-flex justify-content-center foo">
                <div class="card-header-c d-flex">
                    <div class="card-box-ico">
                        <span class="bi bi-cash">$</span>
                    </div>
                    <div class="card-title-c align-self-center">
                        <h5 class="title-c"><?php echo _j($record['listPrice']) ?></h5>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-7 col-lg-7 section-md-t3">
            <div class="row">
                <div class="col-sm-12">
                    <div class="title-box-d">
                        <h3 class="title-d">Property Description</h3>
                    </div>
                </div>
            </div>
            <div class="property-description">
                <p class="description color-text-a"><?php echo _j($record['description']) ?></p>
            </div>

            <div class="property-summary">
                <div class="row">
                    <div class="col-sm-12">
                        <div class="title-box-d section-t4">
                            <h3 class="title-d">Quick Summary</h3>
                        </div>
                    </div>
                </div>
                <div class="summary-list">
                    <ul class="list">
                        <li class="d-flex justify-content-between">
                            <strong>Property ID:</strong>
                            <span><?php echo _j($record['mlsNumber']) ?></span>
                        </li>
                        <li class="d-flex justify-content-between">
                            <strong>Location:</strong>
                            <span><?php echo _j($record['address']['district']) . ', ' . _j($record['address']['state']) . _j($record['address']['zip']); ?></span>
                        </li>
                        <li class="d-flex justify-content-between">
                            <strong>Property Type:</strong>
                            <span><?php echo _j($record['type']); ?></span>
                        </li>
                        <li class="d-flex justify-content-between">
                            <strong>Status:</strong>
                            <span><?php echo _j($record['status']); ?></span>
                            <span> / <?php echo _j($record['lastStatus']); ?></span>
                        </li>
                        <li class="d-flex justify-content-between">
                            <strong>Area:</strong>
                            <span><?php echo (is_array(_j($record['sqft'])) ? '' : _j($record['sqft'])); ?>
                                SqFt
                            </span>
                        </li>
                        <li class="d-flex justify-content-between">
                            <strong>Beds:</strong>
                            <span><?php echo _j($record['numBedrooms']); ?></span>
                        </li>
                        <li class="d-flex justify-content-between">
                            <strong>Baths:</strong>
                            <span><?php echo _j($record['numBathrooms']); ?></span>
                        </li>
                        <li class="d-flex justify-content-between">
                            <strong>Garage:</strong>
                            <span><?php echo _j($record['numGarageSpaces']); ?></span>
                        </li>


                    </ul>
                </div>
            </div>

            <div class="row section-t3">
                <div class="col-sm-12">
                    <div class="title-box-d">
                        <h3 class="title-d">Complete Details</h3>
                    </div>
                </div>
            </div>
            <div class="amenities-list color-text-a">
                <ul class="list-a no-margin">
                    <?php // print_r($proparr); exit;
                    unset($proparr['details']['description']);
                    foreach (_j($proparr['details'], []) as $k => $namenities) {
                        if (is_array(_j($namenities)) || (!(is_array(_j($namenities))) && !(strlen(_j($namenities))))) continue;
                        echo '<li>' . $k . ': <b>' . $namenities . '</b></li>';
                    } ?>
                </ul>
            </div>

            <?php if (count(_j($prophst)) > 0) { ?>
                <div class="row section-t3">
                    <div class="col-sm-12">
                        <div class="title-box-d">
                            <h3 class="title-d">Property History</h3>
                        </div>
                    </div>
                </div>
                <div class="amenities-list color-text-a">
                    <?php // print_r($proparr); exit;
                    // unset ($prophst['details']['description']);
                    echo '<table class="datatable"><thead><tr><th>S.No</th><th>MLS No.</th><th>Style</th><th>Area</th><th>Status</th><th>List Price</th><th>Sold Price</th><th>Sold Date</th></tr></thead><tbody>';
                    foreach (_j($prophst, []) as $k => $hst) {
                        //  print_r($hst); exit;
                        echo '<tr><td>' . ($k + 1) . '</td><td>' . $hst['mlsNumber'] . '</td>
<td>' . $hst['style'] . '</td><td>' . $hst['sqft'] . '</td>
<td>' . $hst['lastStatus'] . '</td><td>' . $hst['listPrice'] . '</td>
<td>' . $hst['soldPrice'] . '</td><td>' . $hst['soldDate'] . '</td></tr>';
                    }
                    echo '</tbody></table>';
                    ?>
                </div>
            <?php } ?>


        </div>
    </div>
</div>
<div class="col-md-10 offset-md-1">
    <ul class="nav nav-pills-a nav-pills mb-3 section-t3" id="pills-tab" role="tablist">
        <li class="nav-item active">
            <a class="nav-link" id="pills-map-tab" data-bs-toggle="pill" href="#pills-map" role="tab" aria-controls="pills-map" aria-selected="false">Location on Map</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" id="pills-video-tab" data-bs-toggle="pill" href="#pills-video" role="tab" aria-controls="pills-video" aria-selected="true">Video</a>
        </li>
    </ul>
    <div class="tab-content" id="pills-tabContent">
        <div class="tab-pane fade" id="pills-plans" role="tabpanel" aria-labelledby="pills-plans-tab">
            <img src="<?php echo BASE; ?>assets/img/plan2.jpg" alt="" class="img-fluid">
        </div>
        <div class="tab-pane fade" id="pills-video" role="tabpanel" aria-labelledby="pills-video-tab">
            <iframe src="<?php echo _j($record['alternateURLVideoLink-disabled']); ?>" width="100%" height="460" frameborder="0" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe>
        </div>
        <div class="tab-pane fade show active" id="pills-map" role="tabpanel" aria-labelledby="pills-map-tab">
            <iframe src="https://www.google.com/maps/embed/v1/place?key=<?php echo $mapikey; ?>&q=<?php echo _j($record['address']['district']) . '+' . _j($record['address']['state']) . '+' . _j($record['address']['zip']); ?>&center=<?php echo _j($record['map']['latitude']); ?>,<?php echo _j($record['map']['longitude']); ?>" src="https://www.google.com/maps/embed?pb=<?php echo _j($record['map']['latitude']); ?>+','+<?php echo _j($record['map']['longitude']); ?>+Square!5e0!3m2!1ses-419!2sve!4v1510329142834" width="100%" height="460" frameborder="0" style="border:0" allowfullscreen></iframe>
        </div>
    </div>
</div>
<div class="col-md-12">
    <div class="row section-t3">
        <div class="col-sm-12">
            <div class="title-box-d">
                <h3 class="title-d">Contact Agent</h3>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-6 col-lg-4">
            <div class="property-agent">
                <h4 class="title-agent"><?php echo _j($record['agent']); ?></h4>
                <p class="color-text-a">
                </p>
                <ul class="list-unstyled">
                    <?php foreach (_j($record['agents'], []) as $k => $agent) { ?>
                        <li class="d-flex justify-content-between">
                            <strong><?php echo $k; ?>:</strong>
                            <span class="color-text-a"><?php echo $agent; ?></span>
                        </li>
                    <?php }; ?>
                </ul>
                <div class="socials-a">
                    <ul class="list-inline">
                        <li class="list-inline-item">
                            <a href="#">
                                <i class="bi bi-facebook" aria-hidden="true"></i>
                            </a>
                        </li>
                        <li class="list-inline-item">
                            <a href="#">
                                <i class="bi bi-twitter" aria-hidden="true"></i>
                            </a>
                        </li>
                        <li class="list-inline-item">
                            <a href="#">
                                <i class="bi bi-instagram" aria-hidden="true"></i>
                            </a>
                        </li>
                        <li class="list-inline-item">
                            <a href="#">
                                <i class="bi bi-linkedin" aria-hidden="true"></i>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="col-md-12 col-lg-4">
            <div class="property-contact">
                <form class="form-a">
                    <div class="row">
                        <div class="col-md-12 mb-1">
                            <div class="form-group">
                                <input type="text" class="form-control form-control-lg form-control-a" id="inputName" placeholder="Name *" required>
                            </div>
                        </div>
                        <div class="col-md-12 mb-1">
                            <div class="form-group">
                                <input type="email" class="form-control form-control-lg form-control-a" id="inputEmail1" placeholder="Email *" required>
                            </div>
                        </div>
                        <div class="col-md-12 mb-1">
                            <div class="form-group">
                                <textarea id="textMessage" class="form-control" placeholder="Comment *" name="message" cols="45" rows="8" required></textarea>
                            </div>
                        </div>
                        <div class="col-md-12 mt-3">
                            <button type="submit" class="btn btn-a">Send Message</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>