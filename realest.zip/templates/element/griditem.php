<?php foreach (_j($records, []) as $record) { ?>

    <div class="col-md-4">
        <div class="card-box-a card-shadow">
            <div class="img-box-a">

                <img src="<?php echo IMG . _j($record['images'][0]); ?>" alt="" class="img-a img-fluid">
            </div>
            <div class="card-overlay">
                <div class="card-overlay-a-content">
                    <div class="card-header-a">
                        <h2 class="card-title-a">
                            <a href="#">
                                <?php echo _j($record['address']['streetNumber']) . ' ' . _j($record['address']['streetName']); ?>
                                <br /><span><?php echo _j($record['address']['district']) . ', ' . _j($record['address']['state']) . _j($record['address']['zip']); ?></span>
                            </a>
                        </h2>
                    </div>
                    <div class="card-body-a">
                        <div class="price-box d-flex">
                            <span class="price-a"><?php echo _j($record['type']); ?> | $ <?php echo _j($record['listPrice']); ?></span>
                        </div>
                        <a href="<?php echo BASE; ?>props/details/<?php echo _j($record['mlsNumber']); ?>" class="link-a">Click here to view
                            <span class="bi bi-chevron-right"></span>
                        </a>
                    </div>
                    <div class="card-footer-a">
                        <ul class="card-info d-flex justify-content-around">
                            <li>
                                <h4 class="card-info-title">Area</h4>
                                <span><?php echo (is_array(_j($record['sqft'])) ? '' : _j($record['sqft'])); ?>
                                    SqFt
                                </span>
                            </li>
                            <li>
                                <h4 class="card-info-title">Beds</h4>
                                <span><?php echo _j($record['numBedrooms']); ?></span>
                            </li>
                            <li>
                                <h4 class="card-info-title">Baths</h4>
                                <span><?php echo _j($record['numBathrooms']); ?></span>
                            </li>
                            <li>
                                <h4 class="card-info-title">Garages</h4>
                                <span><?php echo implode('', _j($record['numGarageSpaces'])); ?></span>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php  }  ?>