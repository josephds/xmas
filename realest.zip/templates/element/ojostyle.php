<div role="scroller" class="mvt-shifter-list">
    <div target="propertyHighlightPanel" class=""><a class="">Features</a></div>
    <div target="propertyBasePanel" class=""><a>Description</a></div>
    <div target="featuresPanel" class=""><a>Overview</a></div>
    <div target="locationPanel" class=""><a>Location</a></div>
    <div target="propertyPoiPanel" class="active"><a>POI</a></div>
    <div target="propertyMortgagePanel" class=""><a>Payment</a></div>
    <div target="propertyEstimatePanel"><a>Home Estimate</a></div>
    <div target="propertySchedulePanel"><a>Request Tour</a></div>
    <div target="soldPanel"><a>Recently Sold</a></div>
    <div target="comparePanel"><a>Comparison</a></div>
    <div target="propertyNearbyPanel"><a>Nearby Homes</a></div>
    <div target="marketStatsPanel"><a>Market Statistics</a></div>
    <div target="propertySchoolPanel"><a>Schools</a></div>
</div>



<div class="layout-left">
    <div class="section">
        <div id="propertyBasePanel" class="panel">
            <div class="record">
                <h2 class="maintitle"><b>Description</b></h2>
                <ul>
                    <li>
                        <div class="key">Home Value ($/Sqft)</div>
                        <div class="value"><span>
$ <?= number_format (_j($record['listPrice']), 0, '.', ',') ?> / 
                            
                        $800/Sqft</span></div>
                    </li>
                    <!---->
                    <li>
                        <div class="key">Property Published</div>
                        <div class="value"><span>
                            <?= strlen(_j($record['listDate'])) > 10 ? date('d-M-Y', strtotime($record['listDate'])) . ' | ' . (date('Ymd') - date('Ymd', strtotime($record['listDate'])) . ' Day(s)') : '' ?>
    | <?= _j($record['lastStatus']) ?>
                            </span></div>
                    </li>
                    <li>
                        <div class="key">Property Type</div>
                        <div class="value"><span><i class="f9 icon-property-condo"></i>
<?= _j($record['class']) ?> | 
                            </span></div>
                    </li>
                    <li>
                        <div class="key">Style</div>
                        <div class="value"><span>
<?= _j($record['style']) ?>
                            </span></div>
                    </li>
                    <li>
                        <div class="key">Neighbourhood</div>
                        <div class="value">
                        <?= _j($record['address']['neighbourhood']) ?>
                        </div>
                    </li>
                    <!---->
                    <li>
                        <div class="key">Community</div>
                        <div class="value"><span>Islington-city Centre West</span></div>
                    </li>
                    <li class="nearbySchoolAvgRating">
                        <div class="key">
                            Median School
                            <a href="javascript:;" tip="This is a Median School Score for all the assigned schools and the nearby schools within a 2KM radius for this home.">
                                Score <i class="f9 text-gray icon-question-circle"></i></a>
                        </div>
                        <div class="value"><a class="link"> 6.9/10 </a></div>
                    </li>
                    <!---->
                    <!---->
                    <!---->
                    <li>
                        <div class="key">Garage Spaces</div>
                        <div class="value"><span>
                                1
                            </span></div>
                    </li>
                    <!---->
                    <!---->
                    <!---->
                    <!---->
                    <li class="apply">
                        <div class="key">Mortgage Payment</div>
                        <div class="value">
                            <!----> <a target="_blank" rel="nofollow noreferrer" class="link-button">Get Pre-qualified Now</a>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
        <div id="propertyDescriptionPanel" class="panel">
            <div class="property-desc"><span>
                    <p>Luxury 2 bed plus sitting room condo in the heart of islington village,steps to islington subway and kipling go train,minutes to downtown toronto!functional split bedroom plan,filled w/natural light,great south west and north west views from one balcony and terrace w/ access from living room and bedroom, floor-to-ceiling windows,sleek laminate floors,modern kitchen w/ plenty of cupboard space,caesar stone countertops, s/s appliances and center island.</p>
                    <p class="market-stats">This property is one of 39 for sale in Islington-City Centre West. The median days on the market for properties in this area is 11 with a median list price of $750K and median cost per square foot of $1062. The list price of this property is 17% above the Islington-City Centre West median, It has a price per square foot of $800, which is 24% below the median and has been on the market for 7 days.</p>
                </span>
                <!---->
                <!---->
            </div>
        </div>
        <div class="panel">
            <!---->
        </div>
        <div class="panel">
            <div class="property-mls">
                <div class="property-agentinfo">
                    RIGHT AT HOME REALTY, BROKERAGE
                    <!---->
                </div>
                <div>
                    MLS®#W5691375
                    <!----> <span>TREB MLS®</span> <span>updated 6 days ago.</span>
                </div>
                <div>OJO checked TREB MLS® for data 8 minutes ago.</div>
                <!---->
            </div>
        </div>
    </div>
    <div class="section" id="featuresPanel">
        <div class="panel">
            <div class="mvt-collapse active disable"><a class="mvt-collapse-link">
                    <h2 class="maintitle"><b>Home Overview</b></h2>
                </a>
                <div class="mvt-collapse-panel">
                    <div class="property-feature box">
                        <div class="record">
                            <div class="record-title">
                                Overview
                                <!---->
                            </div>
                            <ul>
                                <li><span class="key">Virtual Tour</span>
                                    <div class="value"><a rel="nofollow" class="link">External Link</a></div>
                                </li>
                                <li><span class="key">Status</span>
                                    <div class="value"><span>Active</span></div>
                                </li>
                                <li><span class="key">Property Sub Type</span>
                                    <div class="value"><span>Apartment</span></div>
                                </li>
                                <li><span class="key">MLS® #</span>
                                    <div class="value"><span>W5691375</span></div>
                                </li>
                                <li><span class="key">Approx Square Feet (Range)</span>
                                    <div class="value"><span>1000 - 1199</span></div>
                                </li>
                                <li><span class="key">Storage Unit (Locker)</span>
                                    <div class="value"><span>Owned</span></div>
                                </li>
                                <li><span class="key">Basement Information</span>
                                    <div class="value"><span>None</span></div>
                                </li>
                                <li><span class="key">Taxes</span>
                                    <div class="value"><span>
                                            $2,382
                                        </span></div>
                                </li>
                                <li><span class="key">Tax Year</span>
                                    <div class="value"><span>2022</span></div>
                                </li>
                                <li><span class="key">Maintenance Fee</span>
                                    <div class="value"><span>
                                            $830
                                        </span></div>
                                </li>
                            </ul>
                        </div>
                        <div class="record">
                            <div class="record-title">
                                Interior
                                <!---->
                            </div>
                            <ul>
                                <li><span class="key"># Total Bathrooms</span>
                                    <div class="value"><span>2</span></div>
                                </li>
                                <li><span class="key"># Full Baths</span>
                                    <div class="value"><span>2</span></div>
                                </li>
                                <li><span class="key"># of Above Grade Bedrooms</span>
                                    <div class="value"><span>3</span></div>
                                </li>
                                <li><span class="key"># of Below Grade Bedrooms</span>
                                    <div class="value"><span>1</span></div>
                                </li>
                                <li><span class="key">Family Room Available</span>
                                    <div class="value"><span>No</span></div>
                                </li>
                                <li><span class="key">Has Fireplace (Y/N)</span>
                                    <div class="value"><span>Yes</span></div>
                                </li>
                                <li><span class="key">Laundry Information</span>
                                    <div class="value"><span>En Suite Laundry</span></div>
                                </li>
                            </ul>
                        </div>
                        <div class="record">
                            <div class="record-title">
                                Exterior
                                <!---->
                            </div>
                            <ul>
                                <li><span class="key">Construction Materials</span>
                                    <div class="value"><span>Concrete</span></div>
                                </li>
                                <li><span class="key">Building Amenities</span>
                                    <div class="value"><span>Concierge, Gym, Indoor Pool, Media Room, Party/Meeting Room, Sauna</span></div>
                                </li>
                                <li><span class="key"># Garage Spaces</span>
                                    <div class="value"><span>1</span></div>
                                </li>
                                <li><span class="key">Parking Desc</span>
                                    <div class="value"><span>Undergrnd, parking Included, Owned</span></div>
                                </li>
                                <li><span class="key"># Parking Spaces</span>
                                    <div class="value"><span>1</span></div>
                                </li>
                                <li><span class="key">Garage Features</span>
                                    <div class="value"><span>Undergrnd</span></div>
                                </li>
                                <li><span class="key">Has Basement (Y/N)</span>
                                    <div class="value"><span>Yes</span></div>
                                </li>
                                <li><span class="key">Has Garage (Y/N)</span>
                                    <div class="value"><span>Yes</span></div>
                                </li>
                                <li><span class="key">Parking Spot #</span>
                                    <div class="value"><span>30</span></div>
                                </li>
                                <li><span class="key">Exterior Features</span>
                                    <div class="value"><span>Terr</span></div>
                                </li>
                            </ul>
                        </div>
                        <div class="record">
                            <div class="record-title">
                                Amenities / Utilities
                                <!---->
                            </div>
                            <ul>
                                <li><span class="key">Cooling</span>
                                    <div class="value"><span>Central Air</span></div>
                                </li>
                                <li><span class="key">Heat Source</span>
                                    <div class="value"><span>Gas</span></div>
                                </li>
                                <li><span class="key">Heat Type</span>
                                    <div class="value"><span>Forced Air</span></div>
                                </li>
                            </ul>
                        </div>
                        <div class="record">
                            <div class="record-title">
                                Location
                                <!---->
                            </div>
                            <ul>
                                <li><span class="key">Area</span>
                                    <div class="value"><span>Toronto</span></div>
                                </li>
                                <li><span class="key">Community</span>
                                    <div class="value"><span>Islington-City Centre West</span></div>
                                </li>
                                <li><span class="key">Directions</span>
                                    <div class="value"><span>Bloor And Islington</span></div>
                                </li>
                            </ul>
                        </div>
                        <div class="record">
                            <div class="record-title">
                                Lot/ Land Details
                                <!---->
                            </div>
                            <ul>
                                <li><span class="key">Exposure</span>
                                    <div class="value"><span>Se</span></div>
                                </li>
                            </ul>
                        </div>
                        <div class="record">
                            <div class="record-title">
                                Rooms Information
                                <a class="switch-button"><span>metric</span> <i class="icon-toggle-off"></i></a>
                            </div>
                            <ul>
                                <li><span class="key">2nd Bedroom</span>
                                    <div class="value"><span>Large Window: 4.8m X 3.1m<br>Level: Flat</span></div>
                                </li>
                                <li><span class="key">Dining Room</span>
                                    <div class="value"><span>Open Concept: 7.1m X 3.6m<br>Level: Flat</span></div>
                                </li>
                                <li><span class="key">Kitchen</span>
                                    <div class="value"><span>Modern Kitchen: 3.6m X 2.4m<br>Level: Flat</span></div>
                                </li>
                                <li><span class="key">Living Room</span>
                                    <div class="value"><span>Combined W/Dining: 7.1m X 3.6m<br>Level: Flat</span></div>
                                </li>
                                <li><span class="key">Prim Bdrm</span>
                                    <div class="value"><span>W/O To Balcony: 5.2m X 3m<br>Level: Flat</span></div>
                                </li>
                                <li><span class="key">Sitting Room</span>
                                    <div class="value"><span>Laminate: 2.9m X 2.5m<br>Level: Flat</span></div>
                                </li>
                                <li><span class="key">Type 1 Washroom</span>
                                    <div class="value"><span># of Pieces - 4<br>Level: Flat</span></div>
                                </li>
                                <li><span class="key">Type 2 Washroom</span>
                                    <div class="value"><span># of Pieces - 5<br>Level: Flat</span></div>
                                </li>
                            </ul>
                        </div>
                        <p><a class="link">See More</a></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!---->
    <div class="section">
        <div id="locationPanel" class="panel">
            <h2 class="maintitle"><b>Location</b></h2>
            <div class="dpp-map"><a href="javascript:;">
                    <div class="mvt-map-static img">
                        <!----> <img width="400px" height="400px" src="https://maps.googleapis.com/maps/api/staticmap?center=43.643914,-79.529168&amp;maptype=roadmap&amp;zoom=13&amp;markers=icon:https%3A%2F%2Fstatic.ojohome.ca%2F1.0.247%2Fimages%2Fpin%2Fhomeicon.png|43.643914,-79.529168&amp;size=900x360&amp;key=AIzaSyByWbRwiuEmXNj6C7CCo6wbbew2l6tTeT0&amp;signature=yBClsBacViBLXiEmXc7jWbtcmbQ=">
                    </div>
                </a>
                <ul class="tab tab-pills">
                    <li><a>Street View</a></li>
                    <li><a>Satellite</a></li>
                </ul>
            </div>
        </div>
    </div>
    <div class="section">
        <div class="panel">
            <div class="mvt-collapse active disable" id="propertyPoiPanel"><a class="mvt-collapse-link">
                    <h4 class="maintitle"><b>Nearby Points of Interest</b></h4>
                </a>
                <div class="mvt-collapse-panel">
                    
                </div>
            </div>
        </div>
    </div>
    <div class="section" id="propertyMortgagePanel">
        <div class="panel">
            <div class="mvt-collapse active disable" id="propertyMortgagePanel"><a class="mvt-collapse-link">
                    <h4 class="maintitle"><b>Monthly Payment Breakdown</b></h4>
                </a>
                <div class="mvt-collapse-panel">
                    <div class="property-mortgage box inline">
                        <div class="mortgage">
                            <div class="mortgage-panel">
                                <div class="info">
                                    <div class="title">
                                        <div><b class="f5">$5,062</b> <span>/Month</span> <a class="tip"><i class="text-gray f9 icon-question-circle"></i></a> <a class="link mortgage-open"><i class="icon-pencil"></i>Adjust</a></div>
                                        <div class="f10">
                                            25 year at 5 year fixed, 20% Down Payment, 5.340% Interest
                                        </div>
                                    </div>
                                    <div class="chart">
                                        <div type="Interest"><b>$4,232</b>
                                            Principal &amp; Interest
                                            <span class="progress-bar" style="width: 84%;"></span>
                                        </div>
                                        <div type="HOA"><b>$830</b> Maintenance <span class="progress-bar" style="width: 16%;"></span></div>
                                        <div class="preapproved">
                                            <div><a href="javascript:;" rel="nofollow noreferrer" class="btn normal primary active">
                                                    Get Preapproved
                                                </a> <a href="javascript:;" rel="nofollow noreferrer" class="link"><img height="24px" width="24px" src="https://static.ojohome.ca/1.0.247/images/common/rbc-logo.svg" alt="">
                                                    Lock your rate with RBC preapproval
                                                </a></div>
                                            <div class="rbc-info">Mortgage rate is for illustrative purposes only. Please check <a class="link" rel="nofollow" href="http://rbc.com/mortgages" target="_blank">RBC.com/mortgages</a> for the current mortgage rates</div>
                                        </div>
                                    </div>
                                </div>
                                <div class="calcuator">
                                    <div class="group">
                                        <div class="textbox  focus">
                                            <div class="input"><label>Home Price</label> <i>$</i> <input type="tel"></div>
                                        </div>
                                        <div class="textbox  focus">
                                            <div class="input"><label>Monthly Maintenance Dues</label> <i>$</i> <input type="tel"></div>
                                        </div>
                                    </div>
                                    <div class="group">
                                        <div class="textbox  focus">
                                            <div class="input"><label>Down Payment</label> <i>$</i> <input type="tel"></div>
                                        </div>
                                        <div class="textbox  focus">
                                            <div class="input right"><label>Percent</label> <input type="number" step="0.1"> <i>%</i></div>
                                        </div>
                                    </div>
                                    <div class="group">
                                        <div class="textbox  focus">
                                            <div class="input"><label>Property Tax Est.</label> <i>$</i> <input type="tel"></div>
                                        </div>
                                        <div class="textbox  focus">
                                            <div class="input right"><label>Percent</label> <input type="number" step="0.1"> <i>%</i></div>
                                        </div>
                                    </div> <a class="link mortgage-close">Show Less</a>
                                </div>
                            </div>
                            <div class="preapproved mobile">
                                <div><a href="javascript:;" rel="nofollow noreferrer" class="btn normal primary active">
                                        Get Preapproved
                                    </a> <a href="javascript:;" rel="nofollow noreferrer" class="link"><img height="24px" width="24px" src="https://static.ojohome.ca/1.0.247/images/common/rbc-logo.svg" alt="">
                                        Lock your rate with RBC preapproval
                                    </a></div>
                                <div class="rbc-info">Mortgage rate is for illustrative purposes only. Please check <a class="link" rel="nofollow" href="http://rbc.com/mortgages" target="_self">RBC.com/mortgages</a> for the current mortgage rates</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="home-highlight section" id="mvtHighlightPanel">
        <div class="section highlight">
            <h4 class="maintitle"><span>Nearby homes with popular Features</span></h4>
            
        </div>
    </div>
    <div class="section" id="propertyEstimatePanel">
        <div class="panel">
            <div class="mvt-collapse active disable" id="propertyEstimate"><a class="mvt-collapse-link">
                    <h4 class="maintitle home-estimate"><b>Price Estimate </b></h4>
                    <p class="price-estimate-adr"><span class="pe"><?=_j($priceestimate) ?></span> <a href="javascript:void(0)" class="f9 text-gray estimate-tooltip"><i class="icon-question-circle price-estimated-icon"><span class="price-estimated-tooltip">This estimate is based on the list price of this home and nearby listings.<br> This is not a formal appraisal. Share your feedback and questions on this estimate <a href=" https://movotore.typeform.com/to/uy66SdZf" target="_blank" rel="nofollow" class="link">here</a>.</span></i></a> <span> range</span> <span class="er">$880K - $1.14M</span>
                        <!---->
                    </p>
                    <div class="property-estimate-header">
                        <div>
                            <div></div>
                            <div>
                                This estimate is
                                based on the recent nearby listed homes
                            </div>
                        </div>
                    </div>
                </a>
            </div>
        </div>
    </div>
    <div id="propertySchedulePanel" class="section-schedule-tour">
        <div class="section property-schedule mvt-schedule">
            <div class="panel">
                <div class="dpp-hotlead-panel box gray">
                    <div class="dpp-hotlead-photo"><img data-src="https://static.ojohome.ca/p/1001/W5691375_0_zzJfQR_p.jpeg" src="data:image/gif;base64,R0lGODlhAQABAJEAAAAAAP///////wAAACH5BAEAAAIALAAAAAABAAEAAAICVAEAOw==">
                        <!---->
                    </div>
                    <div class="dpp-hotlead-inline text-center half-width">
                        <div>
                            <h6 class="f6 _title">Schedule a Viewing</h6>
                            <div class="">
                                <ul class="tab-pills">
                                    <li><a class="active"><span>In Person</span></a></li>
                                    <li><a class=""><span>Virtual Tour</span></a></li>
                                </ul>
                                <div class="hotleadSelect">
                                    <div class="mvt-shifter" type="2"><a href="javascript:;" class="arrow prev disable"><i class="icon-angle-left"></i></a>
                                        <div role="scroller" class="mvt-shifter-list">
                                            <div class="date-card"><a href="javascript:;" data-calindex="0" class="active-date">
                                                    <div class="f11">MON</div>
                                                    <div class="f5">18</div>
                                                    <div class="f11 text-uppercase">Jul</div>
                                                </a></div>
                                            <div class="date-card"><a href="javascript:;" data-calindex="1" class="next-date">
                                                    <div class="f11">TUE</div>
                                                    <div class="f5">19</div>
                                                    <div class="f11 text-uppercase">Jul</div>
                                                </a></div>
                                            <div class="date-card"><a href="javascript:;" data-calindex="2" class="next-date">
                                                    <div class="f11">WED</div>
                                                    <div class="f5">20</div>
                                                    <div class="f11 text-uppercase">Jul</div>
                                                </a></div>
                                            <div class="date-card"><a href="javascript:;" data-calindex="3" class="next-date">
                                                    <div class="f11">THU</div>
                                                    <div class="f5">21</div>
                                                    <div class="f11 text-uppercase">Jul</div>
                                                </a></div>
                                            <div class="date-card"><a href="javascript:;" data-calindex="4" class="next-date">
                                                    <div class="f11">FRI</div>
                                                    <div class="f5">22</div>
                                                    <div class="f11 text-uppercase">Jul</div>
                                                </a></div>
                                            <div class="date-card"><a href="javascript:;" data-calindex="5" class="next-date">
                                                    <div class="f11">SAT</div>
                                                    <div class="f5">23</div>
                                                    <div class="f11 text-uppercase">Jul</div>
                                                </a></div>
                                            <div class="date-card"><a href="javascript:;" data-calindex="6" class="next-date">
                                                    <div class="f11">SUN</div>
                                                    <div class="f5">24</div>
                                                    <div class="f11 text-uppercase">Jul</div>
                                                </a></div>
                                            <div class="date-card"><a href="javascript:;" data-calindex="7" class="next-date">
                                                    <div class="f11">MON</div>
                                                    <div class="f5">25</div>
                                                    <div class="f11 text-uppercase">Jul</div>
                                                </a></div>
                                            <div class="date-card"><a href="javascript:;" data-calindex="8" class="next-date">
                                                    <div class="f11">TUE</div>
                                                    <div class="f5">26</div>
                                                    <div class="f11 text-uppercase">Jul</div>
                                                </a></div>
                                            <div class="date-card"><a href="javascript:;" data-calindex="9" class="next-date">
                                                    <div class="f11">WED</div>
                                                    <div class="f5">27</div>
                                                    <div class="f11 text-uppercase">Jul</div>
                                                </a></div>
                                            <div class="date-card"><a href="javascript:;" data-calindex="10" class="next-date">
                                                    <div class="f11">THU</div>
                                                    <div class="f5">28</div>
                                                    <div class="f11 text-uppercase">Jul</div>
                                                </a></div>
                                            <div class="date-card"><a href="javascript:;" data-calindex="11" class="next-date">
                                                    <div class="f11">FRI</div>
                                                    <div class="f5">29</div>
                                                    <div class="f11 text-uppercase">Jul</div>
                                                </a></div>
                                            <div class="date-card"><a href="javascript:;" data-calindex="12" class="next-date">
                                                    <div class="f11">SAT</div>
                                                    <div class="f5">30</div>
                                                    <div class="f11 text-uppercase">Jul</div>
                                                </a></div>
                                            <div class="date-card"><a href="javascript:;" data-calindex="13" class="next-date">
                                                    <div class="f11">SUN</div>
                                                    <div class="f5">31</div>
                                                    <div class="f11 text-uppercase">Jul</div>
                                                </a></div>
                                        </div> <a href="javascript:;" class="arrow next"><i class="icon-angle-right"></i></a>
                                    </div>
                                    <div class="group-schedul gap"><a class="btn-schedul active"><b class="text-bolder">Morning</b>
                                            <div class="f6">8am-12pm</div>
                                        </a> <a class="btn-schedul"><b class="text-bolder">Afternoon</b>
                                            <div class="f6">12pm-4pm</div>
                                        </a> <a class="btn-schedul"><b class="text-bolder">Evening</b>
                                            <div class="f6">4pm-8pm</div>
                                        </a></div>
                                    <div class="f12 _sub">
                                        No obligation or purchase necessary, cancel at any time
                                    </div>
                                    <div class="schedule-tour-button"><button class="btn normal primary active">Request Tour</button></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!---->
    <div id="soldPanel" class="sold-listings">
        <div class="mvt-nearby section">
            <div class="sub" style="display: none;">FRESH LISTINGS</div>
            <div class="section nearby">
                <h4 class="maintitle"><span>Recent Sold Near</span> <a href="https://www.ojohome.ca/toronto-on/sold/" class="link">Toronto</a></h4>
                <div class="panel">
                    <div class="">
                        <div>
                            <div class="mvt-shifter"><a href="javascript:;" class="arrow prev disable"><i class="icon-angle-left"></i></a>
                                <div role="scroller" class="mvt-shifter-list">
                                    <!---->
                                    <div mark-id="mark0_43.659389_-79.509416" class="card-property desktop">
                                        <!----> <a title="-------- Toronto, ON --- ---" class="card-property-link sold-card-link">
                                            <div class="card-img">
                                                <div class="img-cover"></div>
                                                <div class="card-texts f9">Real estate boards require a verified account to access sold property details.</div>
                                                <div class="img-home"><img src="https://static.ojohome.ca/1.0.247/images/common/soldhome1.svg"></div>
                                            </div>
                                            <div class="card-info sold-card-info">
                                                <div class="unlock-title f5">Join or Sign in</div>
                                                <div class="unlock-base-info">
                                                    <div><span class="text-bold">—</span><span class="text-tertiary">Bd</span></div>
                                                    <div><span class="text-bold">—</span><span class="text-tertiary">Ba</span></div>
                                                    <div><span class="text-bold">—</span><span class="text-tertiary">Sqft</span></div>
                                                </div>
                                                <div class="text-tertiary f10">-------- Toronto, ON --- ---</div>
                                            </div>
                                        </a>
                                        <div lock="true" class="card-tags left" style="max-width: 250px;"><span class="tag apple">
                                                Recently Sold
                                            </span></div>
                                        <div lock="true" class="card-tags right"><i class="f8 icon-lock"></i></div>
                                    </div>
                                    <div mark-id="mark0_43.76493_-79.410556" class="card-property desktop">
                                        <!----> <a title="-------- Toronto, ON --- ---" class="card-property-link sold-card-link">
                                            <div class="card-img">
                                                <div class="img-cover"></div>
                                                <div class="card-texts f9">Real estate boards require a verified account to unlock sold home prices.</div>
                                                <div class="img-home"><img src="https://static.ojohome.ca/1.0.247/images/common/soldhome2.svg"></div>
                                            </div>
                                            <div class="card-info sold-card-info">
                                                <div class="unlock-title f5">Join or Sign in</div>
                                                <div class="unlock-base-info">
                                                    <div><span class="text-bold">—</span><span class="text-tertiary">Bd</span></div>
                                                    <div><span class="text-bold">—</span><span class="text-tertiary">Ba</span></div>
                                                    <div><span class="text-bold">—</span><span class="text-tertiary">Sqft</span></div>
                                                </div>
                                                <div class="text-tertiary f10">-------- Toronto, ON --- ---</div>
                                            </div>
                                        </a>
                                        <div lock="true" class="card-tags left" style="max-width: 250px;"><span class="tag apple">
                                                Recently Sold
                                            </span></div>
                                        <div lock="true" class="card-tags right"><i class="f8 icon-lock"></i></div>
                                    </div>
                                    <div mark-id="mark0_43.661387_-79.51184" class="card-property desktop">
                                        <!----> <a title="-------- Toronto, ON --- ---" class="card-property-link sold-card-link">
                                            <div class="card-img">
                                                <div class="img-cover"></div>
                                                <div class="card-texts f9">Access sold data and property details.</div>
                                                <div class="img-home"><img src="https://static.ojohome.ca/1.0.247/images/common/soldhome3.svg"></div>
                                            </div>
                                            <div class="card-info sold-card-info">
                                                <div class="unlock-title f5">Join or Sign in</div>
                                                <div class="unlock-base-info">
                                                    <div><span class="text-bold">—</span><span class="text-tertiary">Bd</span></div>
                                                    <div><span class="text-bold">—</span><span class="text-tertiary">Ba</span></div>
                                                    <div><span class="text-bold">—</span><span class="text-tertiary">Sqft</span></div>
                                                </div>
                                                <div class="text-tertiary f10">-------- Toronto, ON --- ---</div>
                                            </div>
                                        </a>
                                        <div lock="true" class="card-tags left" style="max-width: 250px;"><span class="tag apple">
                                                Recently Sold
                                            </span></div>
                                        <div lock="true" class="card-tags right"><i class="f8 icon-lock"></i></div>
                                    </div>
                                    <div mark-id="mark0_43.675895_-79.313296" class="card-property desktop">
                                        <!----> <a title="-------- Toronto, ON --- ---" class="card-property-link sold-card-link">
                                            <div class="card-img">
                                                <div class="img-cover"></div>
                                                <div class="card-texts f9">Unlock sold prices and property details.</div>
                                                <div class="img-home"><img src="https://static.ojohome.ca/1.0.247/images/common/soldhome4.svg"></div>
                                            </div>
                                            <div class="card-info sold-card-info">
                                                <div class="unlock-title f5">Join or Sign in</div>
                                                <div class="unlock-base-info">
                                                    <div><span class="text-bold">—</span><span class="text-tertiary">Bd</span></div>
                                                    <div><span class="text-bold">—</span><span class="text-tertiary">Ba</span></div>
                                                    <div><span class="text-bold">—</span><span class="text-tertiary">Sqft</span></div>
                                                </div>
                                                <div class="text-tertiary f10">-------- Toronto, ON --- ---</div>
                                            </div>
                                        </a>
                                        <div lock="true" class="card-tags left" style="max-width: 250px;"><span class="tag apple">
                                                Recently Sold
                                            </span></div>
                                        <div lock="true" class="card-tags right"><i class="f8 icon-lock"></i></div>
                                    </div>
                                    <div mark-id="mark0_43.639483_-79.582828" class="card-property desktop">
                                        <!----> <a title="-------- Toronto, ON --- ---" class="card-property-link sold-card-link">
                                            <div class="card-img">
                                                <div class="img-cover"></div>
                                                <div class="card-texts f9">Real estate boards require a verified account to access sold property details.</div>
                                                <div class="img-home"><img src="https://static.ojohome.ca/1.0.247/images/common/soldhome1.svg"></div>
                                            </div>
                                            <div class="card-info sold-card-info">
                                                <div class="unlock-title f5">Join or Sign in</div>
                                                <div class="unlock-base-info">
                                                    <div><span class="text-bold">—</span><span class="text-tertiary">Bd</span></div>
                                                    <div><span class="text-bold">—</span><span class="text-tertiary">Ba</span></div>
                                                    <div><span class="text-bold">—</span><span class="text-tertiary">Sqft</span></div>
                                                </div>
                                                <div class="text-tertiary f10">-------- Toronto, ON --- ---</div>
                                            </div>
                                        </a>
                                        <div lock="true" class="card-tags left" style="max-width: 250px;"><span class="tag apple">
                                                Recently Sold
                                            </span></div>
                                        <div lock="true" class="card-tags right"><i class="f8 icon-lock"></i></div>
                                    </div>
                                    <div mark-id="mark0_43.75923_-79.404598" class="card-property desktop">
                                        <!----> <a title="-------- Toronto, ON --- ---" class="card-property-link sold-card-link">
                                            <div class="card-img">
                                                <div class="img-cover"></div>
                                                <div class="card-texts f9">Real estate boards require a verified account to unlock sold home prices.</div>
                                                <div class="img-home"><img src="https://static.ojohome.ca/1.0.247/images/common/soldhome2.svg"></div>
                                            </div>
                                            <div class="card-info sold-card-info">
                                                <div class="unlock-title f5">Join or Sign in</div>
                                                <div class="unlock-base-info">
                                                    <div><span class="text-bold">—</span><span class="text-tertiary">Bd</span></div>
                                                    <div><span class="text-bold">—</span><span class="text-tertiary">Ba</span></div>
                                                    <div><span class="text-bold">—</span><span class="text-tertiary">Sqft</span></div>
                                                </div>
                                                <div class="text-tertiary f10">-------- Toronto, ON --- ---</div>
                                            </div>
                                        </a>
                                        <div lock="true" class="card-tags left" style="max-width: 250px;"><span class="tag apple">
                                                Recently Sold
                                            </span></div>
                                        <div lock="true" class="card-tags right"><i class="f8 icon-lock"></i></div>
                                    </div>
                                    <div mark-id="mark0_43.64054_-79.559638" class="card-property desktop">
                                        <!----> <a title="-------- Toronto, ON --- ---" class="card-property-link sold-card-link">
                                            <div class="card-img">
                                                <div class="img-cover"></div>
                                                <div class="card-texts f9">Access sold data and property details.</div>
                                                <div class="img-home"><img src="https://static.ojohome.ca/1.0.247/images/common/soldhome3.svg"></div>
                                            </div>
                                            <div class="card-info sold-card-info">
                                                <div class="unlock-title f5">Join or Sign in</div>
                                                <div class="unlock-base-info">
                                                    <div><span class="text-bold">—</span><span class="text-tertiary">Bd</span></div>
                                                    <div><span class="text-bold">—</span><span class="text-tertiary">Ba</span></div>
                                                    <div><span class="text-bold">—</span><span class="text-tertiary">Sqft</span></div>
                                                </div>
                                                <div class="text-tertiary f10">-------- Toronto, ON --- ---</div>
                                            </div>
                                        </a>
                                        <div lock="true" class="card-tags left" style="max-width: 250px;"><span class="tag apple">
                                                Recently Sold
                                            </span></div>
                                        <div lock="true" class="card-tags right"><i class="f8 icon-lock"></i></div>
                                    </div>
                                    <div mark-id="mark0_43.651441_-79.566964" class="card-property desktop">
                                        <!----> <a title="-------- Toronto, ON --- ---" class="card-property-link sold-card-link">
                                            <div class="card-img">
                                                <div class="img-cover"></div>
                                                <div class="card-texts f9">Unlock sold prices and property details.</div>
                                                <div class="img-home"><img src="https://static.ojohome.ca/1.0.247/images/common/soldhome4.svg"></div>
                                            </div>
                                            <div class="card-info sold-card-info">
                                                <div class="unlock-title f5">Join or Sign in</div>
                                                <div class="unlock-base-info">
                                                    <div><span class="text-bold">—</span><span class="text-tertiary">Bd</span></div>
                                                    <div><span class="text-bold">—</span><span class="text-tertiary">Ba</span></div>
                                                    <div><span class="text-bold">—</span><span class="text-tertiary">Sqft</span></div>
                                                </div>
                                                <div class="text-tertiary f10">-------- Toronto, ON --- ---</div>
                                            </div>
                                        </a>
                                        <div lock="true" class="card-tags left" style="max-width: 250px;"><span class="tag apple">
                                                Recently Sold
                                            </span></div>
                                        <div lock="true" class="card-tags right"><i class="f8 icon-lock"></i></div>
                                    </div>
                                    <div mark-id="mark0_43.666671_-79.315739" class="card-property desktop">
                                        <!----> <a title="-------- Toronto, ON --- ---" class="card-property-link sold-card-link">
                                            <div class="card-img">
                                                <div class="img-cover"></div>
                                                <div class="card-texts f9">Real estate boards require a verified account to access sold property details.</div>
                                                <div class="img-home"><img src="https://static.ojohome.ca/1.0.247/images/common/soldhome1.svg"></div>
                                            </div>
                                            <div class="card-info sold-card-info">
                                                <div class="unlock-title f5">Join or Sign in</div>
                                                <div class="unlock-base-info">
                                                    <div><span class="text-bold">—</span><span class="text-tertiary">Bd</span></div>
                                                    <div><span class="text-bold">—</span><span class="text-tertiary">Ba</span></div>
                                                    <div><span class="text-bold">—</span><span class="text-tertiary">Sqft</span></div>
                                                </div>
                                                <div class="text-tertiary f10">-------- Toronto, ON --- ---</div>
                                            </div>
                                        </a>
                                        <div lock="true" class="card-tags left" style="max-width: 250px;"><span class="tag apple">
                                                Recently Sold
                                            </span></div>
                                        <div lock="true" class="card-tags right"><i class="f8 icon-lock"></i></div>
                                    </div>
                                    <div mark-id="mark0_43.755168_-79.283414" class="card-property desktop">
                                        <!----> <a title="-------- Toronto, ON --- ---" class="card-property-link sold-card-link">
                                            <div class="card-img">
                                                <div class="img-cover"></div>
                                                <div class="card-texts f9">Real estate boards require a verified account to unlock sold home prices.</div>
                                                <div class="img-home"><img src="https://static.ojohome.ca/1.0.247/images/common/soldhome2.svg"></div>
                                            </div>
                                            <div class="card-info sold-card-info">
                                                <div class="unlock-title f5">Join or Sign in</div>
                                                <div class="unlock-base-info">
                                                    <div><span class="text-bold">—</span><span class="text-tertiary">Bd</span></div>
                                                    <div><span class="text-bold">—</span><span class="text-tertiary">Ba</span></div>
                                                    <div><span class="text-bold">—</span><span class="text-tertiary">Sqft</span></div>
                                                </div>
                                                <div class="text-tertiary f10">-------- Toronto, ON --- ---</div>
                                            </div>
                                        </a>
                                        <div lock="true" class="card-tags left" style="max-width: 250px;"><span class="tag apple">
                                                Recently Sold
                                            </span></div>
                                        <div lock="true" class="card-tags right"><i class="f8 icon-lock"></i></div>
                                    </div>
                                </div> <a href="javascript:;" class="arrow next"><i class="icon-angle-right"></i></a>
                            </div>
                        </div>
                    </div>
                    <!---->
                </div>
            </div>
        </div>
    </div>
    <div class="section property-market-compare" id="comparePanel">
        <div class="panel">
            <div class="mvt-collapse active disable _inline"><a class="mvt-collapse-link">
                    <h4 class="maintitle"><b>Comparison to 30 nearby homes</b></h4>
                    <div class="">
                        <div class="vote"><span>Is this section helpful?</span> <a class="btn"><span class="icon-thumbs-up"></span></a> <a class="btn"><span class="icon-thumbs-down"></span></a></div>
                        <!---->
                    </div>
                </a>
                <div class="mvt-collapse-panel">
                    <div class="property-market">
                        <!---->
                        <div class="property-bar-grid">
                            <div>
                                <div class="property-bar-header">
                                    <div><i class="icon-money"></i>List Price</div>
                                    <div>above median <span>$675K</span></div>
                                </div>
                                <div class="property-bar-title">
                                    <div class="current">$880K
                                        <!---->
                                    </div>
                                    <div class="percent red right">30%</div>
                                </div>
                                <div class="property-bar">
                                    <div class="min">$475K </div>
                                    <div class="bar" style="background: linear-gradient(90deg, rgb(72, 72, 72) 0%, rgb(221, 221, 221) 100%);">
                                        <div class="map-pin" style="left: 98%;"><span class="icon-map-pin-home"><span class="path1"></span><span class="path2"></span></span></div>
                                    </div>
                                    <div class="max">$880K </div>
                                </div>
                            </div>
                            <div>
                                <div class="property-bar-header">
                                    <div><i class="icon-money"></i>Price per Sqft</div>
                                    <div>below avg <span>$913/Sqft</span></div>
                                </div>
                                <div class="property-bar-title">
                                    <div class="current">$800/Sqft
                                        <!---->
                                    </div>
                                    <div class="percent green">12%</div>
                                </div>
                                <div class="property-bar">
                                    <div class="min">$663/Sqft </div>
                                    <div class="bar" style="background: linear-gradient(90deg, rgb(72, 72, 72) 0%, rgb(221, 221, 221) 100%);">
                                        <div class="arrow green" style="left: 25.4365%;"></div>
                                    </div>
                                    <div class="max">$1,122/Sqft </div>
                                </div>
                            </div>
                            <div>
                                <div class="property-bar-header">
                                    <div><i class="icon-bed"></i>Bedrooms</div>
                                    <div>most homes have
                                        <!---->
                                    </div>
                                </div>
                                <div class="property-bar-title">
                                    <div class="current">3<span class="pill green right">Great Value</span></div>
                                    <div class="percent green right">2 bedrooms</div>
                                </div>
                                <div class="property-dotted-bar">
                                    <div class="min">0 bedroom</div>
                                    <div class="progress">
                                        <div class="active green right"></div>
                                        <div class="active green right"></div>
                                        <div class="active green right"></div>
                                    </div>
                                    <div class="max">3 bedrooms</div>
                                </div>
                            </div>
                            <div>
                                <div class="property-bar-header">
                                    <div><i class="icon-bath"></i>Bathrooms</div>
                                    <div>most homes have
                                        <!---->
                                    </div>
                                </div>
                                <div class="property-bar-title">
                                    <div class="current">2<span class="pill green">Great Value</span></div>
                                    <div class="percent green">2 bathrooms</div>
                                </div>
                                <div class="property-dotted-bar">
                                    <div class="min">1 bathroom</div>
                                    <div class="progress">
                                        <div class="active green"></div>
                                        <div class="active green"></div>
                                    </div>
                                    <div class="max">2 bathrooms</div>
                                </div>
                            </div>
                            <div>
                                <div class="property-bar-header">
                                    <div><i class="icon-sqft"></i>HOA Fee</div>
                                    <div>above avg <span>$624</span></div>
                                </div>
                                <div class="property-bar-title">
                                    <div class="current">$830
                                        <!---->
                                    </div>
                                    <div class="percent red right">33%</div>
                                </div>
                                <div class="property-bar">
                                    <div class="min">$280 </div>
                                    <div class="bar" style="background: linear-gradient(90deg, rgb(72, 72, 72) 0%, rgb(221, 221, 221) 100%);">
                                        <div class="arrow red right" style="left: 81.7705%;"></div>
                                    </div>
                                    <div class="max">$929 </div>
                                </div>
                            </div>
                            <!---->
                            <!---->
                        </div>
                        <div class="statistics-calculated-by">* Statistics Calculated by OJOHome</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="section" id="propertyNearbyPanel">
        <div class="panel">
            <h4 class="nearbyHomeTitle"><b>Nearby Homes</b>
                <div class="dropdown tiny right">
                    <!----> <a label="" href="javascript:void(0);"><i class="icon-sort-down"></i> Similar</a>
                    <div class="dropdown-list list-link"><a href="javascript:void(0);">Distance</a><a href="javascript:void(0);" selected="selected">Similar</a><a href="javascript:void(0);">List Date</a><a href="javascript:void(0);">Price (high to low)</a><a href="javascript:void(0);">Price (low to high)</a><a href="javascript:void(0);">Size (big to small)</a><a href="javascript:void(0);">Size (small to big)</a><a href="javascript:void(0);">$ / Sqft (low to high)</a><a href="javascript:void(0);">$ / Sqft (high to low)</a></div>
                </div>
            </h4>
            <p>

        </p>
            <p><a class="link">View On Map</a></p>
        </div>
    </div>
    <div class="section" id="marketStatsPanel">
        <div class="panel">
            <div class="mvt-collapse active disable"><a class="mvt-collapse-link">
                    <h4 class="maintitle"><b>Market Statistics</b></h4>
                </a>
                <div class="mvt-collapse-panel">

            </div>
            </div>
        </div>
    </div>
    <div class="section" id="schoolPanel">
        <div class="panel">
            <div class="mvt-collapse active disable" id="propertySchoolPanel"><a class="mvt-collapse-link">
                    <h4 class="maintitle"><b>Schools</b></h4>
                </a>
            </div>
        </div>
    </div>
    <div class="mvt-lazyload lazy-loading">
        <!---->
    </div>
</div>