<?php $record['empty'] = '-'; ?>
<div role="tablist" class="nav nav-tabs">
    <div class="nav-item" role="presentation"><button id="t00" type="button" class="nav-link" role="tab" data-bs-toggle="tab" data-bs-target="#propertyBasePanel" aria-controls="propertyBasePanel" aria-selected="true">Features</a></div>
    <div class="nav-item" role="presentation"><button id="t01" type="button" class="nav-link" role="tab" data-bs-toggle="tab" data-bs-target="#propertyDescription" aria-controls="propertyDescription" aria-selected="false">Description</a></div>
    <div class="nav-item" role="presentation"><button id="t02" type="button" class="nav-link" role="tab" data-bs-toggle="tab" data-bs-target="#propertyOverview" aria-controls="propertyOverview" aria-selected="false">Overview</a></div>
    <div class="nav-item" role="presentation"><button id="t03" type="button" class="nav-link" role="tab" data-bs-toggle="tab" data-bs-target="#propertyLocation" aria-controls="propertyLocation" aria-selected="false">Location</a></div>
    <div class="nav-item" role="presentation"><button id="t04" type="button" class="nav-link" role="tab" data-bs-toggle="tab" data-bs-target="#propertyPlaces" aria-controls="propertyPlaces" aria-selected="false">Places</a></div>
    <div class="nav-item" role="presentation"><button id="t05" type="button" class="nav-link" role="tab" data-bs-toggle="tab" data-bs-target="#propertyNearby" aria-controls="propertyNearby" aria-selected="false">Nearby</a></div>
    <div class="nav-item" role="presentation"><button id="t06" type="button" class="nav-link" role="tab" data-bs-toggle="tab" data-bs-target="#propertyEstimate" aria-controls="propertyEstimate" aria-selected="false">Estimate</a></div>
    <div class="nav-item" role="presentation"><button id="t07" type="button" class="nav-link" role="tab" data-bs-toggle="tab" data-bs-target="#propertySold" aria-controls="propertySold" aria-selected="false">Sold</a></div>
    <div class="nav-item" role="presentation"><button id="t08" type="button" class="nav-link" role="tab" data-bs-toggle="tab" data-bs-target="#propertyCompare" aria-controls="propertyCompare" aria-selected="false">Compare</a></div>
    <div class="nav-item" role="presentation"><button id="t09" type="button" class="nav-link" role="tab" data-bs-toggle="tab" data-bs-target="#propertySimilar" aria-controls="propertySimilar" aria-selected="false">Similar</a></div>
    <div class="nav-item" role="presentation"><button id="t10" type="button" class="nav-link" role="tab" data-bs-toggle="tab" data-bs-target="#propertyStats" aria-controls="propertyStats" aria-selected="false">Stats</a></div>
    <div class="nav-item" role="presentation"><button id="t11" type="button" class="nav-link" role="tab" data-bs-toggle="tab" data-bs-target="#propertySchools" aria-controls="propertySchools" aria-selected="false">Schools</a></div>
</div>

<div class="tab-content">
    <div id="propertyBasePanel" role="tabpanel" aria-labelledby="t00" class="tab-pane fade active show">
        <div class="record">
            <h2 class="maintitle"><b>Main Features</b></h2>
            <ul>
                <li>
                    <div class="key">Home Value ($/Sqft)</div>
                    <div class="value"><span>
                            $ <?= number_format(_j($record['listPrice']), 0, '.', ',') ?> /
                            /Sqft</span></div>
                </li>
                <!---->
                <li>
                    <div class="key">Property Published</div>
                    <div class="value"><span>
                            <?= strlen(_j($record['listDate'])) > 10 ? date('d-M-Y', strtotime($record['listDate'])) . ' | ' . (date('Ymd') - date('Ymd', strtotime($record['listDate'])) . ' Day(s)') : '' ?>
                            | <?= _j($record['lastStatus']) ?>
                        </span></div>
                </li>
                <li>
                    <div class="key">Property Type</div>
                    <div class="value"><span><i class="f9 icon-property-<?= _j($record['class']) ?>"></i>
                            <?= _j($record['class']) ?> |
                        </span></div>
                </li>
                <li>
                    <div class="key">Style</div>
                    <div class="value"><span>
                            <?= _j($record['style']) ?>
                        </span></div>
                </li>
                <li>
                    <div class="key">Neighbourhood</div>
                    <div class="value">
                        <?= _j($record['address']['neighbourhood']) ?>
                    </div>
                </li>
                <!---->
                <li>
                    <div class="key">Community</div>
                    <div class="value"><span><?= _j($record['address']['communityCode']) ?>
                        </span></div>

                </li>
                <li class="nearbySchoolAvgRating">
                    <div class="key">
                        Median School
                        <a href="javascript:;" tip="This is a Median School Score for all the assigned schools and the nearby schools within a 2KM radius for this home.">
                            Score <i class="f9 text-gray icon-question-circle"></i></a>

                    </div>
                    <div class="value"><a class="link"> 6.9/10 </a></div>
                </li>
                <li>
                    <div class="key">Garage Spaces</div>
                    <div class="value"><span>
                            <?= _j($record['numGarageSpaces']) ?>

                        </span></div>
                </li>
            </ul>
        </div>
    </div>
    <div id="propertyDescription" role="tabpanel" aria-labelledby="t01" class="tab-pane fade">
        <div class="property-desc">
            <p><?= _j($record['description']) ?></p>
        </div>
    </div>
    <div id="propertyOverview" role="tabpanel" aria-labelledby="t02" class="tab-pane fade">
        <div class="panel">
            <div class="mvt-collapse active disable"><a class="mvt-collapse-link">
                    <h2 class="maintitle"><b>Home Overview</b></h2>
                </a>
                <div class="mvt-collapse-panel">
                    <div class="record">
                        <div class="record-title">
                            Overview
                            <!---->
                        </div>
                        <ul>
                            <li><span class="key">Virtual Tour</span>
                                <div class="value"><a rel="nofollow" class="link">External Link</a>
                                    <?= _j($record['empty']) ?></div>

                            </li>
                            <li><span class="key">Status</span>
                                <div class="value"><span><?= _j($record['status']) ?></span></div>

                            </li>
                            <li><span class="key">Property Sub Type</span>
                                <div class="value"><span><?= _j($record['empty']) ?>
                                    </span></div>

                            </li>
                            <li><span class="key">MLS® #</span>
                                <div class="value"><span><?= _j($record['mlsNumber']) ?></span></div>


                            </li>
                            <li><span class="key">Approx Square Feet (Range)</span>
                                <div class="value"><span><?= _j($record['empty']) ?>
                                    </span></div>

                            </li>
                            <li><span class="key">Storage Unit (Locker)</span>
                                <div class="value"><span><?= _j($record['empty']) ?>
                                    </span></div>

                            </li>
                            <li><span class="key">Basement Information</span>
                                <div class="value"><span><?= _j($record['empty']) ?>
                                    </span></div>

                            </li>
                            <li><span class="key">Taxes</span>
                                <div class="value"><span>
                                        <?= _j($record['taxes']['annualAmount']) ?></span></div>
                            </li>
                            <li><span class="key">Tax Year</span>
                                <div class="value"><span><?= _j($record['empty']) ?>
                                    </span></div>

                            </li>
                            <li><span class="key">Maintenance Fee</span>
                                <div class="value"><span>
                                        <?= _j($record['maintenance']) ?>


                                    </span></div>
                            </li>
                        </ul>
                    </div>
                    <div class="record">
                        <div class="record-title">
                            Interior
                            <!---->
                        </div>
                        <ul>
                            <li><span class="key"># Total Bathrooms</span>
                                <div class="value"><span><?= _j($record['empty']) ?></span></div>


                            </li>
                            <li><span class="key"># Full Baths</span>
                                <div class="value"><span><?= _j($record['empty']) ?>
                                    </span></div>

                            </li>
                            <li><span class="key"># of Above Grade Bedrooms</span>
                                <div class="value"><span><?= _j($record['empty']) ?>
                                    </span></div>

                            </li>
                            <li><span class="key"># of Below Grade Bedrooms</span>
                                <div class="value"><span><?= _j($record['empty']) ?></span></div>


                            </li>
                            <li><span class="key">Family Room Available</span>
                                <div class="value"><span><?= _j($record['familyRoom']) ?>
                                    </span></div>

                            </li>
                            <li><span class="key">Has Fireplace (Y/N)</span>
                                <div class="value"><span><?= _j($record['empty']) ?></span></div>
                            </li>
                            <li><span class="key">Laundry Information</span>
                                <div class="value"><span><?= _j($record['empty']) ?>
                                    </span></div>

                            </li>
                        </ul>
                    </div>
                    <div class="record">
                        <div class="record-title">
                            Exterior
                            <!---->
                        </div>
                        <ul>
                            <li><span class="key">Construction Materials</span>
                                <div class="value"><span><?= _j($record['empty']) ?>
                                    </span></div>

                            </li>
                            <li><span class="key">Building Amenities</span>
                                <div class="value"><span><?= _j($record['empty']) ?>
                                    </span></div>

                            </li>
                            <li><span class="key"># Garage Spaces</span>
                                <div class="value"><span><?= _j($record['numGarageSpaces']) ?>
                                    </span></div>

                            </li>
                            <li><span class="key">Parking Desc</span>
                                <div class="value"><span><?= _j($record['empty']) ?></span></div>


                            </li>
                            <li><span class="key"># Parking Spaces</span>
                                <div class="value"><span><?= _j($record['empty']) ?>
                                    </span></div>

                            </li>
                            <li><span class="key">Garage Features</span>
                                <div class="value"><span><?= _j($record['empty']) ?></span></div>


                            </li>
                            <li><span class="key">Has Basement (Y/N)</span>
                                <div class="value"><span><?= _j($record['empty']) ?></span></div>


                            </li>
                            <li><span class="key">Has Garage (Y/N)</span>
                                <div class="value"><span><?= _j($record['empty']) ?></span></div>

                            </li>
                            <li><span class="key">Parking Spot #</span>
                                <div class="value"><span><?= _j($record['empty']) ?></span></div>


                            </li>
                            <li><span class="key">Exterior Features</span>
                                <div class="value"><span><?= _j($record['empty']) ?></span></div>

                            </li>
                        </ul>
                    </div>
                    <div class="record">
                        <div class="record-title">
                            Amenities / Utilities
                            <!---->
                        </div>
                        <ul>
                            <li><span class="key">Cooling</span>
                                <div class="value"><span><?= _j($record['empty']) ?></span></div>

                            </li>
                            <li><span class="key">Heat Source</span>
                                <div class="value"><span><?= _j($record['empty']) ?></span></div>


                            </li>
                            <li><span class="key">Heat Type</span>
                                <div class="value"><span><?= _j($record['empty']) ?></span></div>

                            </li>
                        </ul>
                    </div>
                    <div class="record">
                        <div class="record-title">
                            Location
                            <!---->
                        </div>
                        <ul>
                            <li><span class="key">Area</span>
                                <div class="value"><span>Toronto</span></div>
                                <?= _j($record['area']) ?>

                            </li>
                            <li><span class="key">Community</span>
                                <div class="value"><span><?= _j($record['community']) ?></span></div>


                            </li>
                            <li><span class="key">Directions</span>
                                <div class="value"><span><?= _j($record['empty']) ?></span></div>


                            </li>
                        </ul>
                    </div>
                    <div class="record">
                        <div class="record-title">
                            Lot/ Land Details
                            <!---->
                        </div>
                        <ul>
                            <li><span class="key">Exposure</span>
                                <div class="value"><span><?= _j($record['exposure']) ?></span></div>


                            </li>
                        </ul>
                    </div>
                    <div class="record">
                        <div class="record-title">
                            Rooms Information
                            <a class="switch-button"><span>metric</span><i class="icon-toggle-off"></i></a>
                        </div>
                        <ul>
                            <li><span class="key">2nd Bedroom</span>
                                <div class="value"><span><?= _j($record['empty']) ?></span></div>


                            </li>
                            <li><span class="key">Dining Room</span>
                                <div class="value"><span><?= _j($record['empty']) ?></span></div>


                            </li>
                            <li><span class="key">Kitchen</span>
                                <div class="value"><span><?= _j($record['numKitchens']) ?></span></div>


                            </li>
                            <li><span class="key">Living Room</span>
                                <div class="value"><span><?= _j($record['empty']) ?></span></div>


                            </li>
                            <li><span class="key">Prim Bdrm</span>
                                <div class="value"><span><?= _j($record['empty']) ?></span></div>
                            </li>
                            <li><span class="key">Sitting Room</span>
                                <div class="value"><span><?= _j($record['empty']) ?></span></div>

                            </li>
                            <li><span class="key">Type 1 Washroom</span>
                                <div class="value"><span><?= _j($record['empty']) ?></span></div>


                            </li>
                            <li><span class="key">Type 2 Washroom</span>
                                <div class="value"><span><?= _j($record['empty']) ?></span></div>

                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div id="propertyLocation" role="tabpanel" aria-labelledby="propertyLocation" class="panel tab-pane fade">
        <h2 class="maintitle"><b>Location</b></h2>
        <div class="dpp-map"><a href="javascript:;">
                <div class="mvt-map-static img">
                    <!----> <img width="400px" height="400px" src="https://maps.googleapis.com/maps/api/staticmap?center=43.643914,-79.529168&amp;maptype=roadmap&amp;zoom=13&amp;markers=icon:https%3A%2F%2Fstatic.ojohome.ca%2F1.0.247%2Fimages%2Fpin%2Fhomeicon.png|43.643914,-79.529168&amp;size=900x360&amp;key=AIzaSyByWbRwiuEmXNj6C7CCo6wbbew2l6tTeT0&amp;signature=yBClsBacViBLXiEmXc7jWbtcmbQ=">
                </div>
            </a>
            <ul class="tab tab-pills">
                <li><a>Street View</a></li>
                <li><a>Satellite</a></li>
            </ul>
        </div>
    </div>
    <div id="propertyPlaces" role="tabpanel" aria-labelledby="propertyPlaces" class="panel tab-pane fade">
        <div class="mvt-collapse active disable"><a class="mvt-collapse-link">
                <h4 class="maintitle"><b>Nearby Points of Interest</b></h4>
            </a>
            <div class="mvt-collapse-panel">

            </div>
        </div>
    </div>
    <div id="propertyNearby" role="tabpanel" aria-labelledby="propertyNearby" class="panel tab-pane fade">
        <div class="section highlight">
            <h4 class="maintitle"><span>Nearby homes with popular Features</span></h4>
        </div>
    </div>
    <div id="propertyEstimate" role="tabpanel" aria-labelledby="propertyEstimate" class="panel tab-pane fade">
        <div class="panel">
            <div class="mvt-collapse active disable" id="propertyEstimate"><a class="mvt-collapse-link">
                </a>
            </div>
        </div>
    </div>
    <div id="propertySold" role="tabpanel" aria-labelledby="propertySold" class="panel tab-pane fade">
        <div class="mvt-nearby section">
            <div class="sub" style="display: none;">FRESH LISTINGS</div>
            <div class="section nearby">
                <h4 class="maintitle"><span>Recent Sold Nearby</h4>
                <div class="panel">
                    <div class="">
                        <div>
                        </div>
                    </div>
                    <!---->
                </div>
            </div>
        </div>
    </div>
    <div id="propertyCompare" role="tabpanel" aria-labelledby="propertyCompare" class="panel tab-pane fade">
        <div class="panel">
            <div class="mvt-collapse active disable _inline"><a class="mvt-collapse-link">
                    <h4 class="maintitle"><b>Comparison to nearby homes</b></h4>
                </a>
            </div>
        </div>
    </div>
    <div id="propertySimilar" role="tabpanel" aria-labelledby="propertySimilar" class="panel tab-pane fade">
        <div class="panel">
            <h4 class="nearbyHomeTitle"><b>Nearby Homes</b>
                <div class="dropdown tiny right">
                </div>
            </h4>
            <p>

            </p>
            <p><a class="link">View On Map</a></p>
        </div>
    </div>
    <div id="propertyStats" role="tabpanel" aria-labelledby="propertyStats" class="panel tab-pane fade">
        <div class="panel">
            <div class="mvt-collapse active disable">
                <h4 class="maintitle"><b>Market Statistics</b></h4>
                <div class="mvt-collapse-panel">

                </div>
            </div>
        </div>
    </div>
    <div id="propertySchools" role="tabpanel" aria-labelledby="propertySchools" class="panel tab-pane fade">
        <div class="panel">
            <div class="mvt-collapse active disable" id="propertySchoolPanel"><a class="mvt-collapse-link">
                    <h4 class="maintitle"><b>Schools</b></h4>
                </a>
            </div>
        </div>
    </div>
</div>
<div class="mvt-lazyload lazy-loading">
    <!---->
</div>