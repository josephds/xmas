<div class="intro intro-carousel swiper position-relative">
    <div class="swiper-wrapper">
        <?php foreach (_j($highlights, []) as $record) {
            $i = rand(0, 4); ?>
            <div class="swiper-slide carousel-item-a intro-item bg-image" style="background-image: url(<?php echo IMG . $record['images'][$i]; ?>)">
                <div class="overlay overlay-a"></div>
                <div class="intro-content display-table">
                    <div class="table-cell">
                        <div class="container">
                            <div class="row">
                                <div class="col-lg-8">
                                    <div class="intro-body">
                                        <p class="intro-title-top">
                                            <?php echo _j($record['address']['district']) . ', ' . _j($record['address']['state']) . '<br/>' . _j($record['address']['zip']); ?>
                                        </p>
                                        <h1 class="intro-title mb-4 ">
                                            <span class="color-b"><?php echo _j($record['address']['streetNumber']) . '</span>' . _j($record['address']['streetName']); ?><br />
                                                <?php // echo _j($record['address']['district']) . ', ' . _j($record['address']['state']) . '<br/>' . _j($record['address']['zip']); 
                                                ?>
                                        </h1>
                                        <p class="intro-subtitle intro-price">
                                            <a href="<?php echo BASE; ?>props/details/<?php echo _j($record['mlsNumber']); ?>"><span class="price-a"><?php echo _j($record['type']); ?> | $ <?php echo _j($record['listPrice']) ?></span></a>
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php } ?>
    </div>
    <div class="swiper-pagination"></div>
</div><!-- End Intro Section -->
