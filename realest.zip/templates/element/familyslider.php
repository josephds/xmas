<?php $families = [['src'=>'1000_F_19780454_7L0N8surjLgPWWZty064j1cqIKMWytMv.jpg'],['src'=>'depositphotos_79543850-stock-photo-best-friends.jpg'],
['src'=>'happy-family-house-keys-moving-to-new-home-mortgage-real-estate-concept-mother-father-little-daughter-176981298.jpg'],
['src'=>'happy-family-mother-father-kids-home-couch-174961898.jpg']]; ?>
<div class="intro intro-carousel swiper position-relative">
    <div class="swiper-wrapper">
        <?php foreach (_j($families, []) as $record) {
            $i = rand(0, 4); ?>
            <div class="swiper-slide carousel-item-a intro-item bg-image" style="background-image: url(<?php echo BASE . 'assets/home/' . $record['src']; ?>)">
                <div class="overlay overlay-a"></div>
            </div>
        <?php } ?>
    </div>
    <div class="swiper-pagination"></div>
</div><!-- End Intro Section -->
