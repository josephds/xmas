<?php
    $mapikey = 'AIzaSyD-A4S59PksA4OVZXOLzt5pWDeYMdgTSZ8';
?>

<!-- ======= Intro Single ======= -->
<section class="intro-single">
  <div class="container">
    <div class="row">
      <div class="col-md-12 col-lg-8">
        <div class="title-single-box">
          <h1 class="title-single"><?php echo _j($record['address']['streetNumber']) . ' ' . _j($record['address']['streetName']); ?></h1>
          <span class="color-text-a"><?php echo _j($record['address']['district']) . ', ' . _j($record['address']['state']) . ' ' . _j($record['address']['zip']); ?></span>
        </div>
      </div>
      <div class="col-md-12 col-lg-4">
        <nav aria-label="breadcrumb" class="breadcrumb-box d-flex justify-content-lg-end">
          <ol class="breadcrumb">
            <li class="breadcrumb-item">
              <a href="<?php echo BASE; ?>">Home</a>
            </li>
            <li class="breadcrumb-item">
              <a href="<?php echo BASE; ?>props/listing">Properties</a>
            </li>
            <li class="breadcrumb-item active" aria-current="page">
              <?php echo _j($record['address']['streetNumber']) . ' ' . _j($record['address']['streetName']); ?>
            </li>
          </ol>
        </nav>
      </div>
    </div>
  </div>
</section>
<!-- End Intro Single-->

<!-- ======= Property Single ======= -->
<section class="property-single nav-arrow-b">
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-lg-8">
        <div id="property-single-carousel" class="swiper">
          <div class="swiper-wrapper">
            <?php foreach (_j($record['images'], []) as $img) { ?>
              <div class="carousel-item-b swiper-slide">
                <img src="<?php echo IMG . $img; ?>" alt="">
              </div>
            <?php } ?>
          </div>
        </div>
        <div class="property-single-carousel-pagination carousel-pagination"></div>
      </div>
    </div>

    <div class="row">
    <?php // echo $this->element('details'); ?>
    <?php echo $this->element('ojostyle'); ?>
    </div>
  </div>
</section><!-- End Property Single-->