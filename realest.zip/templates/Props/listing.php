<section class="property-grid grid">
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <div class="grid-option">
                    <form>
                        <select class="custom-select">
                            <option selected>All</option>
                            <option value="1">New to Old</option>
                            <option value="2">For Rent</option>
                            <option value="3">For Sale</option>
                        </select>
                    </form>
                </div>
            </div>
        </div>

        <div class="row">
<?php
        echo $this->element('griditem');
?>
        </div>
        <div class="row">
            <div class="col-sm-12">
                <nav class="pagination-a">
                    <ul class="pagination justify-content-end">
                        <li class="page-item disabled">
                            <a class="page-link" href="#" tabindex="-1">
                                <span class="bi bi-chevron-left"></span>
                            </a>
                        </li>
                        <li class="page-item active">
                            <a class="page-link" href="<?php echo BASE ; ?>props/listing/1">1</a>
                        </li>
                        <li class="page-item">
                            <a class="page-link" href="<?php echo BASE ; ?>props/listing/2">2</a>
                        </li>
                        <li class="page-item">
                            <a class="page-link" href="<?php echo BASE ; ?>props/listing/3">3</a>
                        </li>
                        <li class="page-item next">
                            <a class="page-link" href="#">
                                <span class="bi bi-chevron-right"></span>
                            </a>
                        </li>
                    </ul>
                </nav>
            </div>
        </div>
    </div>
</section><!-- End Property Grid Single-->