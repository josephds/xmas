<?php
declare(strict_types=1);

/**
 * CakePHP(tm) : Rapid Development Framework (https://cakephp.org)
 * Copyright (c) Cake Software Foundation, Inc. (https://cakefoundation.org)
 *
 * Licensed under The MIT License
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 * @copyright     Copyright (c) Cake Software Foundation, Inc. (https://cakefoundation.org)
 * @link          https://cakephp.org CakePHP(tm) Project
 * @since         3.3.4
 * @license       https://opensource.org/licenses/mit-license.php MIT License
 */

namespace App\Controller;

use Cake\Event\EventInterface;

/**
 * Error Handling Controller
 *
 * Controller used by ExceptionRenderer to render error responses.
 */
class PropsController extends AppController
{
    public function index()
    {
        $props = $this->_sapi('listings/property-types'); // stats by prop types
        $proparr = json_decode(_j($props), true);
        $records = [];
        foreach (_j($proparr['boards'][0]['classes'], []) as $k => $proptype) {
            foreach (_j($proptype, []) as $j => $prop) {
                foreach (_j($prop[0], []) as $i => $pr) {
                    $records[$k][$i] = ['count' => $pr['activeCount'], 'style' => $pr['style']];
                }
            }
        }
        $this->set(compact('records'));

        $props = $this->_api('listings?page=2&resultsPerPage=10');
        $proparr = json_decode(_j($props), true);
        $records = $highlights = [];
        foreach (_j($proparr['listings'], []) as $k => $prop) {
                    $highlights[$k] = array_merge(_j($prop['details']),
                     [
                    'mlsNumber' => _j($prop['mlsNumber']), 
                    'class'=> _j($prop['class']),
                    'type'=> _j($prop['type']),
                    'listDate'=> _j($prop['listDate']),
                    'status'=> _j($prop['status']),
                    'lastStatus'=> _j($prop['lastStatus']),
                    'listPrice' => _j($prop['listPrice']),
                    'soldPrice' => _j($prop['soldPrice']),
                    'permissions' => _j($prop['permissions']),
                    'images'=> _j($prop['images']), 'address' => _j($prop['address']),
                    'map' => _j($prop['map']), 'lot'=> _j($prop['lot']),
                    'agent' => _j($prop['agent']),
                    'updatedOn'=> _j($prop['updatedOn']),
                    'office'=> _j($prop['office']),
                    ]);
                    $raw[$k] = $prop;
        }
        $this->set(compact('highlights'));

    }

    public function contact()
    {
    }

    public function listing($filter = 'page', $value = '1')
    {
        $props = $this->_api('listings?' . $filter . '=' . $value, _j($params,[]));
        $proparr = json_decode(_j($props), true);
        $records = $raw = [];
        foreach (_j($proparr['listings'], []) as $k => $prop) {
                    $records[$k] = array_merge(_j($prop['details']),
                     [
                    'mlsNumber' => _j($prop['mlsNumber']), 
                    'class'=> _j($prop['class']),
                    'type'=> _j($prop['type']),
                    'listDate'=> _j($prop['listDate']),
                    'status'=> _j($prop['status']),
                    'lastStatus'=> _j($prop['lastStatus']),
                    'listPrice' => _j($prop['listPrice']),
                    'soldPrice' => _j($prop['soldPrice']),
                    'permissions' => _j($prop['permissions']),
                    'images'=> _j($prop['images']), 'address' => _j($prop['address']),
                    'map' => _j($prop['map']), 'lot'=> _j($prop['lot']),
                    'agent' => _j($prop['agent']),
                    'updatedOn'=> _j($prop['updatedOn']),
                    'office'=> _j($prop['office']),
                    ]);
                    $raw[$k] = $prop;
        }
        $this->set(compact('records', 'raw'));
//        print_r($raw); exit;
    }

    public function details($mls = '')
    {
        $props = $this->_api('listings?mlsNumber='. $mls);
        //        $props = $this->_api('https://sandbox.repliers.io/listings/property-types'); // stats by prop types
//        print_r($props);exit;
        $proparr = json_decode(_j($props,''), true);
        $record = [];
        foreach (_j($proparr['listings'], []) as $k => $prop) {
            $record = array_merge(_j($prop['details']), ['mlsNumber' => _j($prop['mlsNumber']), 
            'class'=> _j($prop['class']),
            'listDate'=> _j($prop['listDate']),
            'status'=> _j($prop['status']),
            'lastStatus'=> _j($prop['lastStatus']),
            'listPrice' => _j($prop['listPrice']),
            'soldPrice' => _j($prop['soldPrice']),
            'permissions' => _j($prop['permissions']),
            'images'=> _j($prop['images']), 'address' => _j($prop['address']),
            'map' => _j($prop['map']), 'lot'=> _j($prop['lot']),
            'agent' => _j($prop['agent']),
            'updatedOn'=> _j($prop['updatedOn']),
            'office'=> _j($prop['office']),
            ]);
        }
        $this->set(compact('record'));
    }


    /**
     * Initialization hook method.
     *
     * @return void
     */
    public function initialize(): void
    {
        $this->loadComponent('RequestHandler');
    }

    /**
     * beforeFilter callback.
     *
     * @param \Cake\Event\EventInterface $event Event.
     * @return \Cake\Http\Response|null|void
     */
    public function beforeFilter(EventInterface $event)
    {
    }

    /**
     * beforeRender callback.
     *
     * @param \Cake\Event\EventInterface $event Event.
     * @return \Cake\Http\Response|null|void
     */
    public function beforeRender(EventInterface $event)
    {
        parent::beforeRender($event);

        //        $this->viewBuilder()->setTemplatePath('Default');
    }

    /**
     * afterFilter callback.
     *
     * @param \Cake\Event\EventInterface $event Event.
     * @return \Cake\Http\Response|null|void
     */
    public function afterFilter(EventInterface $event)
    {
    }
    protected function _api($url, $params=[])
    {
return $this->_sapi($url . '&state=Ontario&class=residential', $params);
    }
    protected function _sapi($url, $params=[])
    {
        $curl = curl_init();
        foreach (_j($params,[]) as $param) {

        }
        curl_setopt_array($curl, array(
            CURLOPT_URL => API . $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_SSL_VERIFYHOST => false,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'GET',
            CURLOPT_HTTPHEADER => ['REPLIERS-API-KEY: taecHelmCkhO5q9QdKZYFmNcCh6YeQ'] // 'Tfh7XmxA1JQ9QXY5Xv8bXhs6DhSN8F'],
        ));
        $response = curl_exec($curl);
        curl_close($curl);
        return ($response);
    }
}
